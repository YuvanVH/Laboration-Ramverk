# v-if
Kolla up vart den ska placeras. Villkorlig rendering

# router-view
app.vue

# computed
finns i app.vue

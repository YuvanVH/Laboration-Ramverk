<!-- <!-- vite/my-project/my-project/src/views/About.vue -->
<template>
  <div>
    <h1>About Page</h1>
    <!-- Kod för about-komponenten här -->
  </div>
</template>

<script>
export default {
  // About-komponentens definition här
};
</script>

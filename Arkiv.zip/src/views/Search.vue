<!-- vite/my-project/my-project/src/views/Search.vue -->
<template>
  <div>
    <h1>Search Page</h1>
    <SearchHoliday />
  </div>
</template>

<script>
import SearchHoliday from '../components/SearchHoliday.vue';

export default {
  components: {
    SearchHoliday,
  },
};
</script>
